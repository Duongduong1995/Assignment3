from django.db import models

# Create your models here.
class Person(models.Model):
    # id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    age = models.IntegerField(null = True)

class Manufacturer(models.Model):
    name = models.CharField(max_length=30)
    address = models.CharField(max_length=200)

class Car(models.Model):
    manufacturer = models.ForeignKey(Manufacturer, on_delete=models.CASCADE)
    name = models.CharField(max_length=30)